// Welcome message after 2 seconds
setTimeout(function() {
  alert("🍴 Welcome to Royal Feast!");
}, 2000);

// ======================
// CART
// ======================

let cart = JSON.parse(localStorage.getItem("cart")) || [];

function addToCart() {
  
  let mealName = document.getElementById("meal-name").textContent;
  let mealPrice = document.getElementById("meal-price").textContent;
  
  let item = {
    name: mealName,
    price: mealPrice,
    quantity: quantity
  };
  
  cart.push(item);
  
  localStorage.setItem("cart", JSON.stringify(cart));
  
  alert("✅ Added to Cart!");
}

// ======================
// LOGIN
// ======================

function login() {
  
  let email = document.getElementById("email").value.trim();
  let password = document.getElementById("password").value.trim();
  
  if (email === "") {
    alert("Please enter your email.");
    return;
  }
  
  if (password === "") {
    alert("Please enter your password.");
    return;
  }
  
  alert("✅ Login successful!");
  
  window.location.href = "home.html";
}

// ======================
// SEARCH
// ======================

function searchMeals() {
  
  let input = document.getElementById("search").value.toLowerCase();
  
  let meals = document.querySelectorAll(".meal");
  
  meals.forEach(function(meal) {
    
    let text = meal.textContent.toLowerCase();
    
    if (text.includes(input)) {
      meal.style.display = "block";
    } else {
      meal.style.display = "none";
    }
    
  });
  
  if (input === "") {
    meals.forEach(function(meal) {
      meal.style.display = "block";
    });
  }
}

// ======================
// CHANGE TEXT
// ======================

function changeText() {
  document.getElementById("message").textContent = "🍔 Enjoy your meal!";
}

// ======================
// GO TO HOME
// ======================

function goHome() {
  window.location.href = "home.html";
}

// ======================
// GO TO SIGNUP
// ======================

function goToSignup() {
  window.location.href = "signup.html";
}
// Create Account
function signup() {
  
  let email = document.getElementById("signup-email").value;
  let password = document.getElementById("signup-password").value;
  
  if (email === "" || password === "") {
    alert("Please fill in all fields.");
    return;
  }
  
  localStorage.setItem("email", email);
  localStorage.setItem("password", password);
  
  alert("✅ Account created successfully!");
  
  window.location.href = "login.html";
}

// Login
function login() {
  
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
  
  let savedEmail = localStorage.getItem("email");
  let savedPassword = localStorage.getItem("password");
  
  if (email === savedEmail && password === savedPassword) {
    
    alert("✅ Welcome back!");
    
    window.location.href = "home.html";
    
  } else {
    
    alert("❌ Incorrect email or password.");
    
  }
  
}
function goHome() {
  window.location.href = "home.html";
}
function checkout() {
  alert("✅ Thank you for ordering from Royal Feast!");
  window.location.href = "checkout.html";
}

function goHome() {
  window.location.href = "home.html";
}
function openMeal(meal) {
  
  localStorage.setItem("meal", meal);
  
  window.location.href = "food.html";
  
}
// Quantity starts at 1
let quantity = 1;

// Increase quantity
function increaseQuantity() {
  
  quantity++;
  
  document.getElementById("quantity").textContent = quantity;
  
}

// Decrease quantity
function decreaseQuantity() {
  
  if (quantity > 1) {
    
    quantity--;
    
    document.getElementById("quantity").textContent = quantity;
    
  }
  
}
function loadCart() {
  
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  
  let cartItems = document.getElementById("cart-items");
  
  if (!cartItems) return;
  
  cartItems.innerHTML = "";
  
  let total = 0;
  
  cart.forEach(function(item, index){
    
   cartItems.innerHTML += `
<div class="meal">
<h3>${item.name}</h3>
<p>${item.price}</p>
<p>Quantity: ${item.quantity}</p>

<button onclick="removeItem(${index})">
🗑️ Remove
</button>

</div>
`;
    
    total += parseFloat(item.price.replace("$", "")) * item.quantity;
    
  });
  
  document.getElementById("total").textContent = total.toFixed(2);
  
}
window.onload = function() {
  loadCart();
};
function removeItem(index) {
  
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  
  cart.splice(index, 1);
  
  localStorage.setItem("cart", JSON.stringify(cart));
  
  loadCart();
  
}
function focusSearch() {
  
  document.getElementById("search").focus();
  
}
function logout() {
  
  localStorage.clear();
  
  alert("Logged out successfully!");
  
  window.location.href = "login.html";
  
}
function favorite(heart) {
  
  if (heart.innerHTML === "🤍") {
    
    heart.innerHTML = "❤️";
    
  } else {
    
    heart.innerHTML = "🤍";
    
  }
  
}
function toggleTheme() {
  
  document.body.classList.toggle("light-mode");
  
}if (document.body.classList.contains("splash")) {
  
  setTimeout(function() {
    
    window.location.href = "login.html";
    
  }, 3000);
}
function saveProfile() {
  
  let phone = document.getElementById("phone").value;
  let address = document.getElementById("address").value;
  
  localStorage.setItem("phone", phone);
  localStorage.setItem("address", address);
  
  alert("✅ Profile Saved!");
  
}

function editProfile() {
  
  document.getElementById("phone").focus();
  
}

function logout() {
  
  localStorage.clear();
  
  alert("Logged Out!");
  
  window.location.href = "login.html";
  
}

window.onload = function() {
  
  if (document.getElementById("phone")) {
    
    document.getElementById("phone").value =
      localStorage.getItem("phone") || "";
    
    document.getElementById("address").value =
      localStorage.getItem("address") || "";
    
  }
  
};